
using System;
using System.Management;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1;

namespace project
{
    public sealed class AuthResult
    {
        public bool Success { get; init; }
        public string Message { get; init; } = string.Empty;
        public string Username { get; init; } = string.Empty;
        public DateTime? ExpireAt { get; init; }
    }

    public static class AuthClient
    {

        public static string AppId = "";
        public static string Version = "";



        public static string ServerUrlOverride = "";


        private static readonly string _encodedUrl =
            "aHR0cHM6Ly9teWF1dGhhcHAuaGVzaGFucnVzaXJ1NzkyLndvcmtlcnMuZGV2";

        private static string ServerUrl =>
            !string.IsNullOrWhiteSpace(ServerUrlOverride)
                ? ServerUrlOverride.TrimEnd('/')
                : Encoding.UTF8.GetString(Convert.FromBase64String(_encodedUrl));

        private static readonly HttpClient _http = new()
        {
            Timeout = TimeSpan.FromSeconds(12)
        };

        private static string? _hwid;


        public static async Task<AuthResult> RegisterAsync(string username, string password, string token)
        {
            if (string.IsNullOrWhiteSpace(username)) return Fail("Username cannot be empty.");
            if (string.IsNullOrWhiteSpace(password)) return Fail("Password cannot be empty.");
            if (string.IsNullOrWhiteSpace(token)) return Fail("Token cannot be empty.");
            if (AppId is "" or "PASTE_YOUR_APP_ID_HERE") return Fail("App ID is not configured.\nOpen Form1.cs and set Form1.AppId.");

            try
            {
                string hwid = GetHwid();
                string url = ServerUrl.TrimEnd('/') + "/api/client-register";

                string json = System.Text.Json.JsonSerializer.Serialize(new
                {
                    appId = AppId,
                    token = token.Trim().ToUpper(),
                    username = username.Trim(),
                    password = password.Trim(),
                    hwid,
                    version = Version
                });

                using var content = new StringContent(json, Encoding.UTF8, "application/json");
                using var resp = await _http.PostAsync(url, content).ConfigureAwait(false);
                string body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);

                var node = JsonNode.Parse(body);
                bool ok = node?["ok"]?.GetValue<bool>() ?? false;
                string msg = node?["message"]?.GetValue<string>() ?? "Unknown error.";

                if (!ok)
                {
                    if (msg.StartsWith("NOT_LATEST_VERSION:", StringComparison.Ordinal))
                        return Fail(msg["NOT_LATEST_VERSION:".Length..]);
                    return Fail(msg);
                }

                return new AuthResult { Success = true, Message = msg, Username = username };
            }
            catch (HttpRequestException) { return Fail("Cannot connect to the server."); }
            catch (TaskCanceledException) { return Fail("Connection timed out."); }
            catch (Exception ex) { return Fail($"Error: {ex.Message}"); }
        }


        public static async Task<AuthResult> LoginAsync(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username))
                return Fail("Username cannot be empty.");

            if (string.IsNullOrWhiteSpace(password))
                return Fail("Password cannot be empty.");

            if (AppId is "PASTE_YOUR_APP_ID_HERE" or "")
                return Fail("App ID is not set.\nOpen Form1.cs and set Form1.AppId.");

            try
            {
                string hwid = GetHwid();
                string url = ServerUrl.TrimEnd('/') + "/api/client-login";

                string json = System.Text.Json.JsonSerializer.Serialize(new
                {
                    appId = AppId,
                    username = username.Trim(),
                    password = password.Trim(),
                    hwid,
                    version = Version
                });

                using var content = new StringContent(json, Encoding.UTF8, "application/json");
                using var resp = await _http.PostAsync(url, content).ConfigureAwait(false);
                string body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);

                var node = JsonNode.Parse(body);
                bool ok = node?["ok"]?.GetValue<bool>() ?? false;
                string msg = node?["message"]?.GetValue<string>() ?? "Unknown server error.";

                if (!ok)
                {

                    if (msg.StartsWith("NOT_LATEST_VERSION:", StringComparison.Ordinal))
                        return Fail(msg["NOT_LATEST_VERSION:".Length..]);

                    return Fail(msg);
                }

                string uname = node?["username"]?.GetValue<string>() ?? username;
                string? expStr = node?["expireAt"]?.GetValue<string>();
                DateTime? expire = expStr is not null
                    ? DateTime.Parse(expStr,
                          System.Globalization.CultureInfo.InvariantCulture,
                          System.Globalization.DateTimeStyles.RoundtripKind)
                    : null;

                return new AuthResult { Success = true, Message = "OK", Username = uname, ExpireAt = expire };
            }
            catch (HttpRequestException)
            {
                return Fail("Cannot connect to the server.\nCheck your internet connection.");
            }
            catch (TaskCanceledException)
            {
                return Fail("Connection timed out.");
            }
            catch (Exception ex)
            {
                return Fail($"Error: {ex.Message}");
            }
        }

        public static string GetHwid()
        {
            if (_hwid is not null) return _hwid;

            string raw = WmiGet("Win32_Processor", "ProcessorId")
                       + WmiGet("Win32_BaseBoard", "SerialNumber")
                       + WmiGet("Win32_DiskDrive", "SerialNumber");

            if (string.IsNullOrWhiteSpace(raw))
                raw = Environment.MachineName;

            using var sha = SHA256.Create();
            var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(raw.Trim()));
            _hwid = BitConverter.ToString(hash).Replace("-", "").ToUpperInvariant();
            return _hwid;
        }

        private static string WmiGet(string cls, string prop)
        {
            try
            {
                using var s = new ManagementObjectSearcher($"SELECT {prop} FROM {cls}");
                foreach (ManagementObject o in s.Get())
                {
                    var v = o[prop]?.ToString()?.Trim();
                    if (!string.IsNullOrWhiteSpace(v)) return v;
                }
            }
            catch { }
            return string.Empty;
        }

        private static AuthResult Fail(string msg) =>
            new() { Success = false, Message = msg };
    }


  
}
