﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            txtLoginUser = new TextBox();
            txtLoginPass = new TextBox();
            button2 = new Button();
            txtRegToken = new TextBox();
            txtRegUser = new TextBox();
            txtRegPass = new TextBox();
            lblRegError = new Label();
            lblLoginError = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(37, 306);
            button1.Name = "button1";
            button1.Size = new Size(193, 112);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtLoginUser
            // 
            txtLoginUser.Location = new Point(26, 74);
            txtLoginUser.Name = "txtLoginUser";
            txtLoginUser.Size = new Size(240, 23);
            txtLoginUser.TabIndex = 1;
            // 
            // txtLoginPass
            // 
            txtLoginPass.Location = new Point(26, 148);
            txtLoginPass.Name = "txtLoginPass";
            txtLoginPass.Size = new Size(240, 23);
            txtLoginPass.TabIndex = 2;
            // 
            // button2
            // 
            button2.Location = new Point(470, 306);
            button2.Name = "button2";
            button2.Size = new Size(193, 112);
            button2.TabIndex = 3;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // txtRegToken
            // 
            txtRegToken.Location = new Point(452, 83);
            txtRegToken.Name = "txtRegToken";
            txtRegToken.Size = new Size(240, 23);
            txtRegToken.TabIndex = 4;
            // 
            // txtRegUser
            // 
            txtRegUser.Location = new Point(452, 130);
            txtRegUser.Name = "txtRegUser";
            txtRegUser.Size = new Size(240, 23);
            txtRegUser.TabIndex = 5;
            // 
            // txtRegPass
            // 
            txtRegPass.Location = new Point(452, 186);
            txtRegPass.Name = "txtRegPass";
            txtRegPass.Size = new Size(240, 23);
            txtRegPass.TabIndex = 6;
            // 
            // lblRegError
            // 
            lblRegError.AutoSize = true;
            lblRegError.Location = new Point(452, 426);
            lblRegError.Name = "lblRegError";
            lblRegError.Size = new Size(80, 15);
            lblRegError.TabIndex = 7;
            lblRegError.Text = "register status";
            // 
            // lblLoginError
            // 
            lblLoginError.AutoSize = true;
            lblLoginError.Location = new Point(35, 422);
            lblLoginError.Name = "lblLoginError";
            lblLoginError.Size = new Size(68, 15);
            lblLoginError.TabIndex = 8;
            lblLoginError.Text = "login status";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblLoginError);
            Controls.Add(lblRegError);
            Controls.Add(txtRegPass);
            Controls.Add(txtRegUser);
            Controls.Add(txtRegToken);
            Controls.Add(button2);
            Controls.Add(txtLoginPass);
            Controls.Add(txtLoginUser);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox txtLoginUser;
        private TextBox txtLoginPass;
        private Button button2;
        private TextBox txtRegToken;
        private TextBox txtRegUser;
        private TextBox txtRegPass;
        private Label lblRegError;
        private Label lblLoginError;
    }
}
