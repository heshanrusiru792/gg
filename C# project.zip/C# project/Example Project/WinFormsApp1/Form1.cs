using System;
using System.ComponentModel;
using System.Windows.Forms;
using project;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Set AuthClient values from Form properties
            AuthClient.AppId = AppId;
            AuthClient.Version = Version;
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AppId { get; set; } = "rPFb5HP6acaQYSMXC11P";

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Version { get; set; } = "1.0.0";

        private async void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            lblLoginError.Visible = false;

            try
            {
                var result = await AuthClient.LoginAsync(txtLoginUser.Text.Trim(), txtLoginPass.Text);

                if (!result.Success)
                {
                    if (IsVersionError(result.Message)) return;

                    lblLoginError.Text = result.Message;
                    lblLoginError.Visible = true;
                    return;
                }

                OnLoginSuccess(result);
            }
            finally
            {
                button1.Enabled = true;
            }
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            lblRegError.Visible = false;

            try
            {
                var result = await AuthClient.RegisterAsync(
                    txtRegUser.Text.Trim(),
                    txtRegPass.Text,
                    txtRegToken.Text.Trim()
                );

                if (!result.Success)
                {
                    if (IsVersionError(result.Message)) return;

                    lblRegError.Text = result.Message;
                    lblRegError.Visible = true;
                    return;
                }

                MessageBox.Show("Registration successful! You can now log in.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                button2.Enabled = true;
            }
        }

        private bool IsVersionError(string message)
        {
            if (message.Contains("Update Required") || message.Contains("Outdated Version"))
            {
                MessageBox.Show(message, "Update Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return true;
            }
            return false;
        }

        private void OnLoginSuccess(AuthResult result)
        {
            string expText = result.ExpireAt.HasValue
                ? result.ExpireAt.Value.ToString("yyyy-MM-dd HH:mm")
                : "Lifetime";

            MessageBox.Show($"Welcome {result.Username}!\nExpires: {expText}", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Dashboard ??? Navigate ???? ?????? Code ?? ????? ?????:
            // Example:
            // MainForm main = new MainForm();
            // main.Show();
            // this.Hide();
        }
    }
}